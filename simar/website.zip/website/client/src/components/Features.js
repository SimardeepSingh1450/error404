import React from 'react'
import FeaturesCard from './FeaturesCard'
const Features = () => {
  return (
    <div>
        <FeaturesCard/>
    </div>
  )
}

export default Features