var arr = [1, 2, 3, 4];
arr.slice(0, 12);
arr.length();
